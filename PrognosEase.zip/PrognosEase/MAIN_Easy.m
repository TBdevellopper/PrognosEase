% Generate data
clear all
clc
%
addpath('PREPROCESSORS','ML','GENERATORS');
%
NUM_Samples =1000;% number of samples
NUM_Features=10;% number of features
% Sellect Sensors measurements trends type
SEN_Trend= 'SEN_RAN';% Sensors measurements trends % 'SEN_L'  =  Linear % 'SEN_E'  =  Exponential % 'SEN_SE' = Sinusoidal grown exponentially % 'SEN_RAN'= random;
% Options linear degradation
Options.Linear.NOISE_Ratio= 0.03;% noise ration
% Otions of Exponential degradation (growth or decay)
% Base of the exponentiation is "e"  
Options.Exponential.Alpha=0.01;% exponentiation parameter "Alpha"
Options.Exponential.NOISE_Ratio=0.5;% noise ration
% Options of Sinusoidal grown exponentially signal
Options.Sinusoidal_exponentia.NOISE_Ratio=0.3;% noise ratio
Options.Sinusoidal_exponentia.Omega=2;%  angular frequancy
Options.Sinusoidal_exponentia.Alpha=0.02;% exponentiation parameter "Alpha"
% Cyclic degradation parameters
Options.Cycle.Pulse_length=100;% Pulse length
Options.Cycle.Distance=50;% distance
Options.Cycle.Alpha=0.1;% % Pulse amplitude  
Options.Cycle.a=0.5;% Normlization parameters
Options.Cycle.b=5;% Normlization parameters
Options.Cycle.NOISE_Ratio=0.9;% noise ratio
Options.Cycle.R=0.7;% Distance increase ratio
Options.Cycle.Type='Lin';% 'Lin'=linear degrdation; % 'Exp'=linear degrdation
Options.Cycle.Alpha_Exp=0.01;
% Distortion Options
Options.Distortion.length_pulse= 50;% Pulse length
Options.Distortion.a=0.5;% Normalization factors
Options.Distortion.Alpha=0.001;% % Pulse amplitude  
Options.Distortion.b=5; % Normalization factors
Options.Distortion.Pulse_Amplutude=0.1;% Pulse amplitude  
Options.Distortion.Number_of_pulses=5;%Number of pulses 
% Sellect RUL trend type
Options.RUL.Alpha=0.01;
RUL_Trend= 'RUL_E';% RUL trend % 'RUL_L'= Linear % 'RUL_E'= Exponential
% Generate data
Ncyles_train=1;% number of life cycles for training
Ncycles_test=1;% number of life cycles for testing
%%
[X,RUL,X_test,RUL_test]= Gen_data(Ncyles_train,Ncycles_test,NUM_Samples,NUM_Features,SEN_Trend,RUL_Trend,Options);
clearvars -except X RUL X_test RUL_test Ncyles_train NUM_Samples Ncycles_test
save('Data\\Data')
%%
% Plot signals
subplot(2,1,1)
plot(X,'DisplayName','X');
ylim([0 1])
xlim([0 NUM_Samples*Ncyles_train])
title('Training set');
xlabel({'Time cycles','(a)'});
ylabel('Measurements');
%
subplot(2,1,2)
plot(X_test,'DisplayName','X');
ylim([0 1])
xlim([0 NUM_Samples*Ncycles_test])
ylabel('Measurements');
title('Testing set');
xlabel({'Time cycles','(b)'});
