function [network]= LSTM_TB(XTrain,YTrain)
% Build regression model with LSTM network
% observation should be organized in a vertical order
featureDimension = size(XTrain,2);
numResponses = size(YTrain,2);
XTrain=XTrain';
YTrain=YTrain';
%% Layers identification
numHiddenUnits = 20;
layers = [ ...
    sequenceInputLayer(featureDimension)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    fullyConnectedLayer(numResponses)
    regressionLayer];

%% Training options (hyperparameters)
maxEpochs = 200;
miniBatchSize = 150;
% adam % sgdm % rmsprop % 0.0000001
options = trainingOptions('adam', ...
    'MaxEpochs',maxEpochs, ...
    'MiniBatchSize',miniBatchSize, ...
    'InitialLearnRate',0.1, ...
    'GradientThreshold',1, ...
    'Shuffle','never', ...
    'L2Regularization',0.01,...
    'ExecutionEnvironment','cpu',...
    'Plots','training-progress',...
    'Verbose',0);
%    'Plots','training-progress',...
tic;
[LSTM,info] = trainNetwork(XTrain,YTrain,layers,options);
Tr_Time=toc;
% %% Testing
% tic;
% Yts_hat = predict(LSTM,XTest,'MiniBatchSize',miniBatchSize);
% Ts_Time=toc;

%% Save results
  network.Tr_Time=Tr_Time;% training time
% network.Ts_Time=Ts_Time;% testing time
% network.yts_hat=Yts_hat;% estimated testing targets
  network.LSTM=LSTM;% trained LSTM
  network.info=info;
end