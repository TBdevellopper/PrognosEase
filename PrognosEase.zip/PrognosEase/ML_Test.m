% Machine learning experiment 
clear all
clc
%
addpath('PREPROCESSORS','GENERATORS','Data','ML');
%
load('Data')
% Training of ML model
[network]= LSTM_TB(X,RUL);
LSTM=network.LSTM;
RUL_hat=predict(LSTM,X');
%%
figure (1)
subplot(2,1,1)
plot(RUL, '--', 'LineWidth',2)
hold on
plot(RUL_hat,'o');
xlim([0 NUM_Samples*Ncyles_train])
ylim([0 1])
title('Training');
xlabel({'Time cycles','(a)'});
ylabel('SoH');
hold off
% Testing of ML model
RUL_test_hat=predict(LSTM,X_test');
subplot(2,1,2)
plot(RUL_test, '--', 'LineWidth',2)
hold on
plot(RUL_test_hat,'o');
xlim([0 NUM_Samples*Ncycles_test]);
ylim([0 1])
hold off
title('Testing');
xlabel({'Time cycles','(b)'});
ylabel('SoH');
