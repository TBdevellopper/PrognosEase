function [X,RUL,X_test,RUL_test]= Gen_data(Ncyles_train,Ncycles_test,NUM_Samples,NUM_Features,SEN_Trend,RUL_Trend,Options)
X=[];% input samples
RUL=[];% targets
X_test=[];% testing samples
RUL_test=[];% testing targets
Options.SEN_RANDOM.idx=1;
for i=1:Ncyles_train
% Generating Signals 
[x,Options]=Signal_Gen(NUM_Samples,NUM_Features,SEN_Trend,Options);
X=[X;x];
% 'RUL_L'= Linear
% 'RUL_E'= Exponential
[rul]=RUL_Gen(NUM_Samples,RUL_Trend,Options);
RUL=[RUL;rul];
Options.SEN_RANDOM.idx=0;
end
Options.SEN_RANDOM.idx=0;
for i=1:Ncycles_test
% Generating Signals 

[x_test]=Signal_Gen(NUM_Samples,NUM_Features,SEN_Trend,Options);
X_test=[X_test;x_test];
% 'RUL_L'= Linear
% 'RUL_E'= Exponential
[rul_test]=RUL_Gen(NUM_Samples,RUL_Trend,Options);
RUL_test=[RUL_test; rul_test];
end
end