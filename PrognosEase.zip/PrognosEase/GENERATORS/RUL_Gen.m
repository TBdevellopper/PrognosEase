function [X]=RUL_Gen(NUM_Samples,RUL_Trend,Options)

switch (RUL_Trend)
%
     case {'RUL_L'}
    [X]=RUL_linear(NUM_Samples);
     case {'RUL_E'}
    [X]= RUL_Exponential(NUM_Samples,Options);
  

end

end