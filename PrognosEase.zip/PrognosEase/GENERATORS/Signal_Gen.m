function [X,Options]=Signal_Gen(NUM_Samples,NUM_Features,SEN_Trend,Options)
% Generating a degradation nalysis dataset
switch (SEN_Trend)
%
     case {'SEN_L'}%
    [X]=SEN_linear(NUM_Samples,NUM_Features,Options);
     case {'SEN_E'}
    [X]= SEN_Exponential(NUM_Samples,NUM_Features,Options);
     case {'SEN_SE'}
    [X]=SEN_Sinusoidal_exponential(NUM_Samples,NUM_Features,Options); 
     case {'SEN_CYC'}   
    [X]=SEN_Cycle(NUM_Samples,NUM_Features,Options);
     case {'SEN_RAN'}
    [X,Options]=SEN_RANDOM(NUM_Features,NUM_Samples,Options);
 

end