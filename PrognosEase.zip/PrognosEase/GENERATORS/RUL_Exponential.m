function [X]= RUL_Exponential(NUM_Samples,Options)
% RUL exponential 
Alpha=Options.RUL.Alpha;
      x=exp(Alpha*(0:NUM_Samples))';
      X=scaledata(-x,0,1);    
end