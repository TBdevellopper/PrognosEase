function [X]=SEN_Distort(X,Options)
%% Distorston of measurements
length_pulse=Options.Distortion.length_pulse;
a=Options.Distortion.a;
b=Options.Distortion.b;
Pulse_Amplutude=Options.Distortion.Pulse_Amplutude;
Alpha=Options.Distortion.Alpha;

%
D=zeros(1,length(X));
E=(-ceil(length_pulse/2):ceil(length_pulse/2));
%
I=find(E>0);
s(I)=Alpha*exp(log(a)*(E(I)/b));
I=find(E<=0);
s(I)=Alpha*exp(-log(a)*(E(I)/b));

%
number_of_pulses=Options.Distortion.Number_of_pulses;
for i= 1: number_of_pulses
Poistion=randi([1,length(X)-(length_pulse)],1,1);
D(Poistion:Poistion+length(s)-1)=s;
D=scaledata(D,0,Pulse_Amplutude);
%
X=X+D';
end