function [x]=CYC_linear(NUM_Samples,NOISE_Ratio)
% Linear cyclic degradation
signal=(0:NUM_Samples);
         a=1/NUM_Samples;
         b=1;
         I=randi([0,1],1,1);
         x=(a*signal+b);
         [x]=scaledata(addnoise(x',NOISE_Ratio),0,1);
%          if I==1
%          [x]=scaledata(addnoise(x',NOISE_Ratio),0,1);
%          else
%          [x]=scaledata(-addnoise(x',NOISE_Ratio),0,1);
%          end

end