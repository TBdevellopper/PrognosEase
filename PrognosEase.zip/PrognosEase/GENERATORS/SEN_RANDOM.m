function [X,Options]=SEN_RANDOM(NUM_Features,NUM_Samples,Options)
% adatset with random types of measurmenets
X=[];
S=[];
 if Options.SEN_RANDOM.idx==1
     Index_TB=randi([1,5],1,NUM_Features);
     Options.SEN_RANDOM.Index_TB=Index_TB;
    for i=1:NUM_Features
     if Index_TB(i)==1
    [X]= SEN_linear(NUM_Samples,1,Options);
     elseif Index_TB(i)==2
    [X]= SEN_Exponential(NUM_Samples,1,Options);
     elseif Index_TB(i)==3
    [X]= SEN_Sinusoidal_exponential(NUM_Samples,1,Options); 
     elseif Index_TB(i)==4
    Options.Cycle.Type='Lin';
    [X]= SEN_Cycle(NUM_Samples,1,Options);
     elseif Index_TB(i)==5
    Options.Cycle.Type='Exp';
    [X]= SEN_Cycle(NUM_Samples,1,Options);
     end
    S=[S X];
    end

    
    
 elseif Options.SEN_RANDOM.idx==0
     Index_TB=Options.SEN_RANDOM.Index_TB;
     Options.SEN_RANDOM.Index_TB=Index_TB;
    for i=1:NUM_Features
     if Index_TB(i)==1
    [X]= SEN_linear(NUM_Samples,1,Options);
     elseif Index_TB(i)==2
    [X]= SEN_Exponential(NUM_Samples,1,Options);
     elseif Index_TB(i)==3
    [X]= SEN_Sinusoidal_exponential(NUM_Samples,1,Options); 
     elseif Index_TB(i)==4
    Options.Cycle.Type='Lin';
    [X]=SEN_Cycle(NUM_Samples,1,Options);
     elseif Index_TB(i)==5
    Options.Cycle.Type='Exp';
    [X]= SEN_Cycle(NUM_Samples,1,Options);
     end
    S=[S X];
    end
     
     
     
 end
 X=S;   
end