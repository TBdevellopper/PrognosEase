function [X]= SEN_Exponential(NUM_Samples,NUM_Features,Options)
% genrate Exponential measurements 
Alpha=Options.Exponential.Alpha;
NOISE_Ratio=Options.Exponential.NOISE_Ratio;
X=[];
for i=1:NUM_Features
      I=randi([0,1],1,1);
      x=exp(Alpha*(0:NUM_Samples));
      [x]=addnoise(x',NOISE_Ratio);
      x=scaledata(x,0,1);

%       if I==1
%       x=scaledata(x,0,1);
%       else
%       x=scaledata(-x,0,1);    
%       end
      %Signal distortion
      [x]=SEN_Distort(x,Options);
      %
      X=[X x];
end
end