function [X]=SEN_Sinusoidal_exponential(NUM_Samples,NUM_Features,Options)
X=[]; 
NOISE_Ratio=Options.Sinusoidal_exponentia.NOISE_Ratio;
Omega=Options.Sinusoidal_exponentia.Omega;
Alpha=Options.Sinusoidal_exponentia.Alpha;

for i=1:NUM_Features
      x=exp(Alpha*(0:NUM_Samples)).*cos(Omega*(0:NUM_Samples));
      x=scaledata(x,0,1);
      %Signal distortion
      [x]=SEN_Distort(x',Options)';
      % adding noise
      [x]=addnoise(x',NOISE_Ratio);
      X=[X x];
 end
end