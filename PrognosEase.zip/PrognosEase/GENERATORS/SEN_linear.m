function [X]=SEN_linear(NUM_Samples,NUM_Features,Options)
% This function is used to linearly generate a degradation dataset.
% Parameters
% NUM_Samples : number of samples in a signal.
% NUM_Features : number of features in the dataset.
% Options:
NOISE_Ratio=Options.Linear.NOISE_Ratio;
X=[];
signal=(0:NUM_Samples);
         a=1/NUM_Samples;
         b=1;
     for i= 1:NUM_Features
         I=randi([0,1],1,1);
         %x=(a*signal+b).*(0.02*cos(Alpha.Omega_L*signal)); 
         x=(a*signal+b);
         %Signal distortion
         [x]=SEN_Distort(x',Options)';
         %
         [x]=scaledata(addnoise(x',NOISE_Ratio),0,1);
%          if I==1
%          [x]=scaledata(addnoise(x',NOISE_Ratio),0,1);
%          else
%          [x]=scaledata(-addnoise(x',NOISE_Ratio),0,1);
%          end
         X=[X x];
     end
end