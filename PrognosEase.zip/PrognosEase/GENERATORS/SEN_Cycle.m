function [X]=SEN_Cycle(NUM_Samples,NUM_Features,Options)
% Cyclic degradation
S=[];
Pulse_length=Options.Cycle.Pulse_length;
Distance=Options.Cycle.Distance;
Alpha=Options.Cycle.Alpha;
a=Options.Cycle.a;
b=Options.Cycle.b;
NOISE_Ratio=Options.Cycle.NOISE_Ratio;
%% generate pulses
for i=1:NUM_Features
D=zeros(1,Distance);
E=(-ceil(Pulse_length/2):ceil(Pulse_length/2));
t=0;
X=[];
while t<(NUM_Samples+1)
I=find(E>0);
s(I)=Alpha*exp(log(a)*(E(I)/b));
I=find(E<=0);
s(I)=Alpha*exp(-log(a)*(E(I)/b));
X=[X D s];
t=length(X);
D=D*Options.Cycle.R;% decrease ratio
end
X=X(1:NUM_Samples+1)';
if Options.Cycle.Type=='Lin'
X_L=CYC_linear(NUM_Samples,NOISE_Ratio);
elseif Options.Cycle.Type=='Exp'
X_L= CYC_Exponential(NUM_Samples,NOISE_Ratio,Options);
end
X=X+X_L;
X=scaledata(X,0,1);
%Signal distortion
[X]=SEN_Distort(X,Options);
%
S=[S X];
end
X=S;
end