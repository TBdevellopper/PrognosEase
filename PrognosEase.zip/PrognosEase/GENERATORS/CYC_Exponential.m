function [x]= CYC_Exponential(NUM_Samples,NOISE_Ratio,Options)
% Eponential cyclic degradation function 
Alpha=Options.Cycle.Alpha_Exp;
      x=exp(Alpha*(0:NUM_Samples));
      [x]=addnoise(x',NOISE_Ratio);
      x=scaledata(x,0,1);


end