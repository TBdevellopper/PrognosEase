function [X]=RUL_linear(NUM_Samples)
% RUL linear 
signal=(0:NUM_Samples);
         a=1/NUM_Samples;
         b=1;
         x=(a*signal+b); 
         [X]=scaledata(-x',0,1);

   
end